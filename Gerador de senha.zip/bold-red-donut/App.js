import React, { useState } from 'react';
import { StyleSheet, Text, View, Button, Clipboard, Alert } from 'react-native';

const App = () => {
  const [password, setPassword] = useState('');

  const generatePassword = () => {
    const length = 8;
    const charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()';
    let result = '';
    for (let i = 0; i < length; i++) {
      const randomIndex = Math.floor(Math.random() * charset.length);
      result += charset[randomIndex];
    }
    setPassword(result);
  };

  const copyToClipboard = () => {
    Clipboard.setString(password);
    Alert.alert('Senha copiada!', password);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Gerador de Senha Aleatória</Text>
      <Text style={styles.password}>{password}</Text>
      <Button title="Gerar Senha" onPress={generatePassword} />
      {password ? (
        <Button title="Copiar Senha" onPress={copyToClipboard} />
      ) : null}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  title: {
    fontSize: 24,
    marginBottom: 16,
  },
  password: {
    fontSize: 32,
    marginBottom: 16,
    fontWeight: 'bold',
  },
});

export default App;